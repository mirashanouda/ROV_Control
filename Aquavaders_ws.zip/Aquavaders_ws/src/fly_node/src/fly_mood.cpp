
#include <ros/ros.h>
#include <std_msgs/String.h>
#include "std_msgs/Float64.h"
#include <std_msgs/Bool.h>
#include <stdio.h>
#include <string.h>
#include <cstring>
#include <sstream>
#include <stdlib.h>
#include <string>
#define motorA motor_def_A
#define motorB motor_def_B
#define motorC motor_def_C
#define motorD motor_def_D
#define motorE motor_def_E
#define motorF motor_def_F
#define fly_pos 1700
#define fly_neg 1200
std::string ph = "P0";
int motorA = 1500, motorB = 1500, motorC = 1500, motorD= 1500, motorE= 1500, motorF= 1500;
std_msgs::String msg;
void forward()
{
  motorA = fly_pos;
  motorB = fly_pos;
  motorC = fly_pos;
  motorD = fly_pos;
}
void right()
{
  motorA = fly_pos;
  motorB = fly_neg;
  motorC = fly_pos;
  motorD = fly_neg;
}
void left()
{
  motorA = fly_neg;
  motorB = fly_pos;
  motorC = fly_neg;
  motorD = fly_pos;
}
void up()
{
  motorE = fly_pos;
  motorF = fly_pos;
}
void down()
{
  motorE = fly_neg;
  motorF = fly_neg;
}
void concatenate_values(){
  std::stringstream ss;
  char buffer[4] = "";
  char l_buffer[4] = "";
  char r_buffer[4] = "";
  ss << "A" << motor_def_A << "B" <<  motor_def_B << "C" <<  motor_def_C
   << "D" <<  motor_def_D << "E" <<  motor_def_E << "F" <<  motor_def_F
   << "Z";
  msg.data = ss.str();
}
class mapper
{
   
public:
  void callback(const std_msgs::String::ConstPtr& dir){//
      if(dir->data == "f")
      {
          forward();
          ROS_INFO("forward");
      }
      else if (dir->data == "u") //Tilting
      {
          up();
          ROS_INFO("up");
      }
      else if(dir->data == "d")
      {
          down();
          ROS_INFO("down");
      }
      else if(dir->data == "r")
      {
          right();
          ROS_INFO("right");
      }
      else if(dir->data == "l")
      {
          left();
          ROS_INFO("left");
      }
      else motorA = 1500, motorB = 1500, motorC = 1500, motorD= 1500, motorE= 1500, motorF= 1500;
      concatenate_values();
      rovpub.publish(msg);
   }
  ros::NodeHandle nh;
  ros::Publisher rovpub;
  ros::Subscriber dirsub;
  mapper(){} 
   void start(){
      rovpub = nh.advertise<std_msgs::String>("motor_values", 1000);
      dirsub = nh.subscribe<std_msgs::String>("directions", 1000, &mapper::callback, this);
  }
};
int main(int argc, char** argv)
{
  ros::init(argc, argv, "map_motors");
  ROS_INFO_STREAM("Executing main");
  mapper m;
  m.start();
  ros::NodeHandle nh("~");
  nh.getParam("ph", ph);
  ROS_INFO("Got parameter: %s", ph.c_str());
  ros::spin();
  return 0;
}
 

