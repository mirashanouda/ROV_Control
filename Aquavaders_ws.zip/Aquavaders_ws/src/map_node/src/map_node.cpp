#include <ros/ros.h>
#include <sensor_msgs/Joy.h>
#include <std_msgs/String.h>
#include "std_msgs/Float64.h"
#include <std_msgs/Bool.h>
#include <stdio.h>
#include <string.h>
#include <cstring>
#include <sstream>
#include <stdlib.h>
#include <string>

#define motorA motor_def_A
#define motorB motor_def_B
#define motorC motor_def_C
#define motorD motor_def_D
#define motorE motor_def_E
#define motorF motor_def_F


#define range 200
#define rot_range 100


int motorA = 1500, motorB = 1500, motorC = 1500, motorD= 1500, motorE= 1500, motorF= 1500;
int led_button = 0, gripper_button = 0;
std_msgs::String msg;

/*void forwardBackward(const sensor_msgs::Joy::ConstPtr &joy)
{
    motorA = 1500 + joy->axes[2] * 300; //motorA = 1500 + joy->axes[1]/32767.0 * 300;
    motorB = 1500 + joy->axes[2] * 300;
    motorC = 1500 + joy->axes[2] * 300;
    motorD = 1500 + joy->axes[2] * 300;
}

void rightLeft(const sensor_msgs::Joy::ConstPtr &joy)
{
    motorA = 1500 - joy->axes[3] * 300;
    motorB = 1500 + joy->axes[3] * 300;
    motorC = 1500 - joy->axes[3] * 300;
    motorD = 1500 + joy->axes[3] * 300;
}

void upDown(const sensor_msgs::Joy::ConstPtr &joy)
{
    motorE = 1550 + joy->axes[1] * 300;
    motorF = 1450 - joy->axes[1] * 300;
}*/





class mapper
{
public:
    void joyCallback(const sensor_msgs::Joy::ConstPtr &joy){//
        if (joy->axes[2] != 0) //Tilting
        {
            forwardBackward(joy->axes[2]);
            ROS_INFO("normal forward backward");
        }
        else if(joy->axes[3] != 0)
        {
            rightLeft(joy->axes[3]);
            ROS_INFO("normal right left");
        }
        else if(joy->axes[1] != 0){
            upDown(joy->axes[1]);
            ROS_INFO("normal up down");
        }
        else motorA = 1500, motorB = 1500, motorC = 1500, motorD= 1500, motorE= 1500, motorF= 1500;

        if(joy->buttons[4]) led_button = 1;
        else led_button = 0;

        if(joy->buttons[5]) gripper_button = 1;
        else gripper_button = 0;

        //rotation 
        if(joy->buttons[6]){
            r_right();
            ROS_INFO("rotate right");
        }
        if(joy->buttons[7]){
            r_left();
            ROS_INFO("rotate left");
        }

        
        concatenate_values();
        rovpub.publish(msg);
    
    }
        mapper(){}  

        void start(){
        rovpub = nh.advertise<std_msgs::String>("motor_values", 1000);
        joysub = nh.subscribe<sensor_msgs::Joy>("joy", 1000, &mapper::joyCallback, this);
    }

private: 
    ros::NodeHandle nh;
    ros::Publisher rovpub;
    ros::Subscriber joysub;

    void forwardBackward(double y)
{
    motorA = 1500 + y * range; //motorA = 1500 + joy->axes[1]/32767.0 * 300;
    motorB = 1500 - y * range;
    motorC = 1500 - y * range;
    motorD = 1500 + y * range;

}

void rightLeft(double x)
{
    motorA = 1500 - x * range;
    motorB = 1500 - x * range;
    motorC = 1500 + x * range;
    motorD = 1500 + x * range;
}

void upDown(double z)
{
    motorE = 1550 + z * range;
    motorF = 1450 + z * range;
}

void concatenate_values(){

    std::stringstream ss;
    char buffer[4] = "";
    char l_buffer[4] = "";
    char r_buffer[4] = "";

    ss << "A" << motor_def_A << "B" <<  motor_def_B << "C" <<  motor_def_C
     << "D" <<  motor_def_D << "E" <<  motor_def_E << "F" <<  motor_def_F 
     << "G" << gripper_button << "L" << led_button << "Z";

    msg.data = ss.str();
}


void r_right(){
    motorA = 1500 + rot_range; //range = 100
    motorB = 1500 - rot_range;
    motorC = 1500 - rot_range;
    motorD = 1500 + rot_range;
}
void r_left(){
    motorA = 1500 - rot_range; //range = 100
    motorB = 1500 + rot_range;
    motorC = 1500 + rot_range;
    motorD = 1500 - rot_range;
}

//diagonal move
/*
void up_right(){
    motorA = 1500 + rot_range; //range = 100
    motorD = 1500 + rot_range;
}
void up_left(){
    motorB = 1500 + rot_range;
    motorC = 1500 + rot_range;
}
void down_right(){
    motorA = 1500 - rot_range; //range = 100
    motorD = 1500 - rot_range;
}
void down_left(){
    motorB = 1500 - rot_range; //range = 100
    motorC = 1500 - rot_range;
}   
*/
    
};

int main(int argc, char** argv)
{
    ros::init(argc, argv, "map_motors");
    ROS_INFO_STREAM("Executing main");
    mapper m;
    m.start();

    //ros::NodeHandle nh("~");
    //nh.getParam("ph", ph);
    //ROS_INFO("Got parameter: %s", ph.c_str());

    ros::spin();
    return 0;
}